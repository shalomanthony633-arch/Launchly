# Launchly

A SaaS platform that turns business details into a polished, ready-to-publish
website. No coding required.

Built in phases. This README is the source of truth for what's done, what's
stubbed, and what to build next — read it first in any new session before
writing code.

---

## Tech stack

- **Next.js 15** (App Router) — see note on version below
- **React 18**
- **TypeScript**
- **Tailwind CSS**
- **Prisma** + **SQLite** (dev) — see Phase 2 note on Postgres for production
- **NextAuth v4** (credentials provider, JWT sessions)
- **bcryptjs** for password hashing
- **Zod** for validation
- **lucide-react** for icons

## Getting started

```bash
npm install
cp .env.example .env
# generate a real secret: openssl rand -base64 32
# paste it into NEXTAUTH_SECRET in .env
npx prisma db push   # creates prisma/dev.db from schema.prisma
npm run dev
```

Visit `http://localhost:3000`.

## Verifying the build

```bash
npm run typecheck   # tsc --noEmit
npm run build        # production build
```

Both were run and passed clean as of Phase 1 (Next.js 15.2.8, Node 22).

---

## ⚠️ Important: Next.js version note

Phase 1 was originally scoped against Next.js 14, but **Next.js 14 reached
End-of-Life in October 2025** and was hit by a wave of CVEs in Dec 2025,
including a critical RCE in the React Server Components protocol
(CVE-2025-66478) and a couple of follow-up DoS/source-exposure CVEs. Since
this is a new long-term project, I upgraded to **Next.js 15.2.8** (a
currently-supported, patched line) instead of building on an EOL version from
day one. React was kept at **18** (not 19) — this sidesteps the RSC-protocol
CVE class entirely, since those are React-19-specific.

**Action for future sessions:** before adding new dependencies or doing a
version bump, check https://nextjs.org/blog for newer security advisories —
this space moves fast. If the person asks to upgrade Next.js/React major
versions later, treat that as a deliberate decision to flag, not a silent
bump.

---

## Phase status

### ✅ Phase 1 — Auth, dashboard shell, landing page (DONE)

- Landing page: nav, hero, template showcase (Restaurant / Barber Shop /
  Hotel — visual only, no functionality yet), how-it-works, CTA, footer.
- Auth: `/signup` and `/login` pages, real NextAuth credentials flow with
  bcrypt-hashed passwords, Zod-validated forms, working logout (dashboard
  topbar user menu).
- Dashboard: protected layout (`getServerSession` + redirect if
  unauthenticated), sidebar with all 7 nav items (Dashboard, My Websites,
  Templates, Domains, Analytics, Billing, Settings), topbar with user menu.
- Main dashboard page: stat cards (Websites / Website status / Subscription
  / Visitors), "Create Website" button (**not wired to anything yet — no
  builder exists**), empty-state recent activity.
- All 6 remaining dashboard subpages exist as real routes with clean empty
  states — not fake links, but no real data or functionality behind them.
- Reusable UI primitives: `Button`, `Input`, `Label`, `Card`, `FormError`,
  `Logo` — built once in `src/components/ui/`, reused everywhere. Extend
  these rather than creating new one-off components in later phases.

**Known, deliberate placeholder:** `src/lib/user-store.ts` is an in-memory
`Map`, not a database. It's documented in the file itself. All account data
is lost on server restart and isn't shared across serverless instances. This
was intentional — Phase 1 scope was explicitly "auth pages + dashboard
layout," not the database. **Phase 2 replaces this.**

The contract `user-store.ts` exposes (`findUserByEmail`, `createUser`,
`findUserById`) is what the rest of the app (NextAuth config, signup route)
depends on. When Phase 2 swaps in Prisma/Postgres, keep those function
signatures stable so the swap doesn't ripple into `src/lib/auth.ts` or the
API routes.

### ⚠️ Phase 2 — verification status

Phase 2 code was **not run or build-checked** before delivery — the sandbox
this was built in blocks `binaries.prisma.sh`, which Prisma's CLI requires
even just to parse the schema file (`prisma generate`, `prisma validate`,
and by extension `next build`, all fail at that step). Phase 1 was fully
verified (typecheck + build passed); this phase was not, by necessity, and
this doc says so plainly rather than claiming otherwise.

What that means practically: this is real, complete, carefully-reviewed
code, not a stub — but you're the first to actually compile and run it.
**Run these commands locally first, in this order, before assuming
anything's broken in your own edits:**

```bash
npm install
cp .env.example .env
# generate a real secret: openssl rand -base64 32 → paste into NEXTAUTH_SECRET
npx prisma db push        # creates prisma/dev.db from schema.prisma
npm run typecheck
npm run build
npm run dev
```

If `npm run typecheck` or `npm run build` throws errors, they're almost
certainly in one of these Prisma-type-sensitive files (in rough order of
likelihood, based on where the type surface is widest):

1. `src/lib/website-data.ts` — `toWebsiteData()`, the function mapping
   Prisma's `Website`/`WebsiteImage` rows into the app's `WebsiteData` shape
2. `src/app/api/websites/[id]/duplicate/route.ts` — copies a website + its
   images, touches the most Prisma fields at once
3. `src/app/api/websites/[id]/images/route.ts` — the `kind as "LOGO" | ...`
   cast is the most likely spot for an enum mismatch
4. `src/components/website-builder/website-builder.tsx` — the client
   component; errors here are more likely plain React/TS issues than
   Prisma ones, since it never imports `@prisma/client` directly

Paste any error output back and it'll be a fast, targeted fix rather than
a re-review of the whole phase.

### ✅ Phase 2 — Database & website builder (BUILT, unverified — see above)

- **Database**: Prisma + SQLite (dev). `User`, `Website`, `WebsiteImage`
  models. Swapping to Postgres for production is a `datasource` provider
  change + `DATABASE_URL` — see the schema comment in `prisma/schema.prisma`.
  `src/lib/user-store.ts` now queries the real DB (same function contract
  as Phase 1's in-memory version, so `auth.ts` didn't need to change).
- **3 templates**: Restaurant (warm/editorial), Barber Shop (bold/dark/
  high-contrast), Hotel (airy/luxury/gallery-forward) — genuinely different
  layouts, not one skin with 3 colors. Each consumes the shared
  `WebsiteData` shape from `src/lib/website-data.ts`. New templates: build
  the component, add one line to `src/components/templates/
  template-registry.tsx`, add the id to `TEMPLATE_IDS`/`TEMPLATE_LABELS`.
- **Create Website flow**: `/dashboard/websites/new` — split-screen, form
  on the left (`WebsiteBuilder` component), live preview on the right that
  re-renders on every keystroke via React state (no page refresh, no
  network round-trip for the preview itself).
- **Image upload**: logo + hero (single-slot, replace-on-reupload) and
  gallery (multi-slot, up to 10). Instant local preview via
  `URL.createObjectURL` before the upload network call resolves. Files
  land on local disk under `public/uploads/{userId}/{websiteId}/`, isolated
  behind `src/lib/storage.ts` — swapping to S3/Cloudinary later means
  changing that one file, not every caller.
- **Save**: `WebsiteBuilder` lazily creates a draft `Website` row on first
  image upload (uploads need a `websiteId` to scope to), then a real PATCH
  on Save. Validated both client-side (inline errors) and server-side
  (Zod, `src/lib/validation.ts`) — never trusts the client alone.
- **Dashboard website management**: `/dashboard/websites` now renders real
  data — a card grid showing business name, template, status (Draft/
  Published), last-updated date. Each card has a menu: Edit, Duplicate
  (copies the DB row + all image files), Delete (removes DB rows + files
  on disk, with a confirm step).
- **Ownership checks**: every website API route verifies the requesting
  user owns the website before reading/writing it
  (`src/lib/website-ownership.ts`), returning a generic 404 either way so
  one user can't probe for another's website ids.

**Known limitation carried into Phase 3:** removing a logo/hero image
without immediately re-uploading a replacement clears it from the UI but
doesn't delete the file or DB row server-side yet (see the comment in
`handleRemoveLogo` in `website-builder.tsx`). Low-impact — orphaned files
only, no data leakage — but worth fixing when Phase 3 revisits image
handling.

### ⬜ Phase 3 — Website publishing (NOT STARTED)

Per the original brief, explicitly deferred out of Phase 2: AI content
generation, actually publishing a site live, custom domains, billing,
analytics, site health monitoring, SEO tools.

---

## Folder structure

```
prisma/
  schema.prisma            User, Website, WebsiteImage models
src/
  app/
    (marketing)/          Landing page route group (nav + footer layout)
      page.tsx
      layout.tsx
    (auth)/                Auth route group (centered card layout)
      login/page.tsx
      signup/page.tsx
      layout.tsx
    (dashboard)/           Protected route group (sidebar + topbar layout)
      dashboard/
        page.tsx           Main dashboard (real stat counts, recent activity)
        websites/
          page.tsx          My Websites — real data, card grid
          new/page.tsx       Create Website (WebsiteBuilder, mode="create")
          [id]/edit/page.tsx  Edit Website (WebsiteBuilder, mode="edit")
        templates/page.tsx
        domains/page.tsx
        analytics/page.tsx
        billing/page.tsx
        settings/page.tsx
      layout.tsx            Session check + redirect happens here
    api/
      auth/[...nextauth]/route.ts
      signup/route.ts
      websites/
        route.ts              GET (list), POST (create)
        [id]/
          route.ts              GET, PATCH (edit), DELETE
          duplicate/route.ts     POST — copies DB row + image files
          images/route.ts        POST (upload), DELETE (remove one image)
    layout.tsx              Root layout (Inter font, SessionProvider)
    globals.css
  components/
    ui/                    Button, Input, Textarea, Label, Card, FormError, Logo
    marketing/              Nav, footer, hero, sections, signup/login forms
    dashboard/               Sidebar, topbar, stat card, empty state,
                               website-card.tsx (edit/duplicate/delete menu)
    templates/                The 3 website templates users' sites render as
      restaurant/restaurant-template.tsx
      barber/barber-template.tsx
      hotel/hotel-template.tsx
      shared/                 image-placeholder.tsx, brand-color-scope.tsx
      template-registry.tsx    templateId → component lookup (single source
                                 of truth — add new templates here)
    website-builder/           The create/edit form + live preview
      website-builder.tsx        Owns all form state, split-screen layout
      form-section.tsx            Section wrapper for visual consistency
      template-picker.tsx
      services-editor.tsx
      image-upload-slot.tsx       Single-image (logo/hero) w/ instant preview
      gallery-upload.tsx           Multi-image gallery uploader
      color-picker.tsx
      preview-frame.tsx             Browser-chrome wrapper for the preview
    session-provider.tsx     NextAuth SessionProvider client wrapper
  lib/
    auth.ts                  NextAuth config (credentials provider)
    prisma.ts                 Prisma client singleton
    user-store.ts              Real DB-backed user queries (Prisma)
    website-data.ts             Shared WebsiteData type contract + helpers
                                  (this is the placeholder system — the
                                  single shape templates/forms/DB all agree on)
    website-ownership.ts          getOwnedWebsite() — ownership check used by
                                    every website API route
    storage.ts                     Local-disk file upload/delete, isolated
                                     so swapping to S3/Cloudinary later is a
                                     one-file change
    session.ts                      getSessionUserId() helper for API routes
    validation.ts              Zod schemas (signup, login, website form)
    utils.ts                    cn() class-merging helper
  types/
    user.ts                   AppUser / PublicUser types
    next-auth.d.ts             Type augmentation adding id to session.user
```

## Design tokens (for consistency in later phases)

Defined in `tailwind.config.ts`:
- **Primary (blue):** `primary-600` (#2563EB) as the main action color
- **Success (green):** `success-600` (#16A34A)
- **Ink (text):** `ink-950` / `ink-900` / `ink-700`
- **Slate (secondary text):** `slate-500` / `slate-400`
- **Borders:** `border` (#E5E7EB), `border-strong` for dashed/emphasis
- **Radius:** `rounded-xl` (14px) is the default card/button radius,
  `rounded-2xl` for larger surfaces
- **Shadows:** `shadow-card` (resting), `shadow-card-hover`, `shadow-glow`
  (used sparingly — signup/login card, hero)

Stick to these tokens rather than introducing new one-off colors in later
phases — this is what keeps the Stripe/Linear/Vercel feel consistent as the
app grows.
