import { PrismaClient } from "@prisma/client";

// Prevents exhausting DB connections from Next.js hot-reload creating a new
// PrismaClient on every file change in dev.
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma = global.__prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  global.__prisma = prisma;
}
