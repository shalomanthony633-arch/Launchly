import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

/** Returns the current session user's id, or null if unauthenticated.
 * Use in every API route that touches user-owned data. */
export async function getSessionUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions);
  return session?.user?.id ?? null;
}
