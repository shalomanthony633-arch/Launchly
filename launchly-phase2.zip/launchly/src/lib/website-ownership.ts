import { prisma } from "@/lib/prisma";
import type { Website, WebsiteImage } from "@prisma/client";

export type WebsiteWithImages = Website & { images: WebsiteImage[] };

/**
 * Fetches a website by id and confirms it belongs to userId.
 * Returns null if the website doesn't exist OR belongs to someone else —
 * deliberately not distinguishing the two in the response, so a caller
 * can't probe for the existence of other users' website ids.
 */
export async function getOwnedWebsite(
  websiteId: string,
  userId: string
): Promise<WebsiteWithImages | null> {
  const website = await prisma.website.findUnique({
    where: { id: websiteId },
    include: { images: true },
  });

  if (!website || website.userId !== userId) {
    return null;
  }

  return website;
}
