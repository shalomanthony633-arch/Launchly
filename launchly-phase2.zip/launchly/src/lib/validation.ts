import { z } from "zod";

export const signupSchema = z.object({
  name: z.string().trim().min(2, "Enter your full name"),
  email: z.string().trim().email("Enter a valid email address"),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Include at least one uppercase letter")
    .regex(/[0-9]/, "Include at least one number"),
});

export type SignupInput = z.infer<typeof signupSchema>;

export const loginSchema = z.object({
  email: z.string().trim().email("Enter a valid email address"),
  password: z.string().min(1, "Enter your password"),
});

export type LoginInput = z.infer<typeof loginSchema>;

export const websiteFormSchema = z.object({
  templateId: z.enum(["RESTAURANT", "BARBER", "HOTEL"]),
  businessName: z.string().trim().min(2, "Enter a business name").max(80),
  description: z.string().trim().min(10, "Description should be at least 10 characters").max(600),
  phone: z.string().trim().min(7, "Enter a valid phone number").max(30),
  whatsapp: z.string().trim().min(7, "Enter a valid WhatsApp number").max(30),
  email: z.string().trim().email("Enter a valid email address"),
  address: z.string().trim().min(5, "Enter a physical address").max(200),
  openingHours: z.string().trim().min(3, "Enter your opening hours").max(200),
  services: z
    .array(z.string().trim().min(1).max(60))
    .max(20, "Add up to 20 services"),
  brandColor: z
    .string()
    .regex(/^#([0-9A-Fa-f]{6})$/, "Enter a valid hex color, e.g. #2563EB"),
});

export type WebsiteFormInput = z.infer<typeof websiteFormSchema>;
