import { writeFile, mkdir, unlink } from "fs/promises";
import path from "path";
import { v4 as uuidv4 } from "uuid";

/**
 * Local-disk file storage for uploaded images.
 *
 * Everything that reads/writes uploaded files goes through this module.
 * When the project moves to a real object store (S3, Cloudinary, R2), only
 * this file changes — callers just get a URL back either way.
 */

const UPLOAD_ROOT = path.join(process.cwd(), "public", "uploads");
const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
const MAX_BYTES = 5 * 1024 * 1024; // 5MB per image

export class UploadError extends Error {}

export async function saveUploadedImage(
  file: File,
  scope: { userId: string; websiteId: string }
): Promise<string> {
  if (!ALLOWED_TYPES.has(file.type)) {
    throw new UploadError("Only JPG, PNG, WEBP, or GIF images are allowed");
  }
  if (file.size > MAX_BYTES) {
    throw new UploadError("Images must be 5MB or smaller");
  }

  const dir = path.join(UPLOAD_ROOT, scope.userId, scope.websiteId);
  await mkdir(dir, { recursive: true });

  const ext = file.type === "image/jpeg" ? "jpg" : file.type.split("/")[1];
  const filename = `${uuidv4()}.${ext}`;
  const filePath = path.join(dir, filename);

  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(filePath, buffer);

  // Public URL — files under /public are served statically by Next.js.
  return `/uploads/${scope.userId}/${scope.websiteId}/${filename}`;
}

/** Deletes a previously-saved image given its public URL. Safe to call on
 * a URL that no longer exists on disk (e.g. already removed). */
export async function deleteUploadedImage(url: string): Promise<void> {
  if (!url.startsWith("/uploads/")) return;
  const filePath = path.join(process.cwd(), "public", url);
  try {
    await unlink(filePath);
  } catch {
    // File already gone — not an error condition for this function's caller.
  }
}
