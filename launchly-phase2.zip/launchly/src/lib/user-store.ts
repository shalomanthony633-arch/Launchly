import { prisma } from "@/lib/prisma";
import type { User } from "@prisma/client";

/**
 * Real, database-backed replacement for Phase 1's in-memory user store.
 * Function names match the old contract on purpose (findUserByEmail,
 * createUser, findUserById) so auth.ts and the signup route didn't need to
 * change their call sites — only the implementation underneath changed.
 */

export function findUserByEmail(email: string): Promise<User | null> {
  return prisma.user.findUnique({
    where: { email: email.trim().toLowerCase() },
  });
}

export function findUserById(id: string): Promise<User | null> {
  return prisma.user.findUnique({ where: { id } });
}

export function createUser(input: {
  name: string;
  email: string;
  passwordHash: string;
}): Promise<User> {
  return prisma.user.create({
    data: {
      name: input.name,
      email: input.email.trim().toLowerCase(),
      passwordHash: input.passwordHash,
    },
  });
}
