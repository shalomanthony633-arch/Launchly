import type { Website, WebsiteImage } from "@prisma/client";

/**
 * This is the placeholder contract referenced in the Phase 1 README:
 * every template component, the create/edit form, and the live preview all
 * consume exactly this shape. Add a field here once, wire it into the form
 * and templates, and it's available everywhere consistently.
 */
export const TEMPLATE_IDS = ["RESTAURANT", "BARBER", "HOTEL"] as const;
export type TemplateId = (typeof TEMPLATE_IDS)[number];

export const TEMPLATE_LABELS: Record<TemplateId, string> = {
  RESTAURANT: "Restaurant",
  BARBER: "Barber Shop",
  HOTEL: "Hotel",
};

export interface WebsiteFormData {
  templateId: TemplateId;
  businessName: string;
  description: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  openingHours: string;
  services: string[];
  brandColor: string;
}

export interface WebsiteImages {
  logo: string | null;
  hero: string | null;
  gallery: string[];
}

/** Full shape a template component renders from. */
export type WebsiteData = WebsiteFormData & { images: WebsiteImages };

export const EMPTY_WEBSITE_FORM: WebsiteFormData = {
  templateId: "RESTAURANT",
  businessName: "",
  description: "",
  phone: "",
  whatsapp: "",
  email: "",
  address: "",
  openingHours: "",
  services: [],
  brandColor: "#2563EB",
};

export const EMPTY_WEBSITE_IMAGES: WebsiteImages = {
  logo: null,
  hero: null,
  gallery: [],
};

/** Parses the DB's JSON-string `services` field into a real string array. */
export function parseServices(raw: string): string[] {
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((s) => typeof s === "string") : [];
  } catch {
    return [];
  }
}

export function serializeServices(services: string[]): string {
  return JSON.stringify(services.filter((s) => s.trim().length > 0));
}

/** Maps a Prisma Website + its images into the shape templates consume. */
export function toWebsiteData(
  website: Website,
  images: WebsiteImage[]
): WebsiteData {
  return {
    templateId: website.templateId as TemplateId,
    businessName: website.businessName,
    description: website.description,
    phone: website.phone,
    whatsapp: website.whatsapp,
    email: website.email,
    address: website.address,
    openingHours: website.openingHours,
    services: parseServices(website.services),
    brandColor: website.brandColor,
    images: {
      logo: images.find((i) => i.kind === "LOGO")?.url ?? null,
      hero: images.find((i) => i.kind === "HERO")?.url ?? null,
      gallery: images.filter((i) => i.kind === "GALLERY").map((i) => i.url),
    },
  };
}
