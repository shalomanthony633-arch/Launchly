export function FormError({ message }: { message?: string | null }) {
  if (!message) return null;

  return (
    <p role="alert" className="mt-1.5 text-sm text-red-600">
      {message}
    </p>
  );
}
