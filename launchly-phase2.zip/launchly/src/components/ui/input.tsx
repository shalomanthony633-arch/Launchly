import { forwardRef } from "react";
import type { InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  hasError?: boolean;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, hasError = false, ...props }, ref) => {
    return (
      <input
        ref={ref}
        className={cn(
          "h-10 w-full rounded-xl border bg-white px-3.5 text-sm text-ink-900",
          "placeholder:text-slate-400",
          "transition-colors duration-150",
          "focus:border-primary-500",
          hasError
            ? "border-red-400 focus:ring-red-200"
            : "border-border focus:border-primary-500",
          className
        )}
        {...props}
      />
    );
  }
);

Input.displayName = "Input";
