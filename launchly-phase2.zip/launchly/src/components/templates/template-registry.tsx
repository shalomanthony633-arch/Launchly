import type { ComponentType } from "react";
import type { TemplateId, WebsiteData } from "@/lib/website-data";
import { RestaurantTemplate } from "@/components/templates/restaurant/restaurant-template";
import { BarberTemplate } from "@/components/templates/barber/barber-template";
import { HotelTemplate } from "@/components/templates/hotel/hotel-template";

/**
 * Single source of truth mapping a templateId to its component. Adding a
 * new template later means: build the component, add one line here, add
 * one entry to TEMPLATE_IDS/TEMPLATE_LABELS in website-data.ts. Nothing
 * else in the app needs to change.
 */
export const TEMPLATE_COMPONENTS: Record<
  TemplateId,
  ComponentType<{ data: WebsiteData }>
> = {
  RESTAURANT: RestaurantTemplate,
  BARBER: BarberTemplate,
  HOTEL: HotelTemplate,
};

export function renderTemplate(data: WebsiteData) {
  const Template = TEMPLATE_COMPONENTS[data.templateId];
  return <Template data={data} />;
}
