import { MapPin, Phone, Clock, MessageCircle } from "lucide-react";
import type { WebsiteData } from "@/lib/website-data";
import { ImagePlaceholder } from "@/components/templates/shared/image-placeholder";
import { BrandColorScope } from "@/components/templates/shared/brand-color-scope";

export function RestaurantTemplate({ data }: { data: WebsiteData }) {
  const { businessName, description, phone, whatsapp, address, openingHours, services, images } =
    data;

  return (
    <BrandColorScope color={data.brandColor}>
      <div className="bg-[#FBF9F5] text-[#2A2420]">
        {/* Hero */}
        <section className="relative h-[420px] w-full overflow-hidden">
          {images.hero ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={images.hero}
              alt={businessName || "Restaurant hero"}
              className="h-full w-full object-cover"
            />
          ) : (
            <ImagePlaceholder className="h-full w-full" label="Hero image" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-8">
            {images.logo && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={images.logo}
                alt="Logo"
                className="mb-3 h-12 w-12 rounded-full border-2 border-white/80 object-cover"
              />
            )}
            <h1 className="font-serif text-4xl italic text-white md:text-5xl">
              {businessName || "Your Restaurant Name"}
            </h1>
          </div>
        </section>

        {/* Description */}
        <section className="mx-auto max-w-2xl px-8 py-12 text-center">
          <p className="text-[15px] leading-relaxed text-[#5C5248]">
            {description || "Tell your guests what makes your kitchen worth visiting."}
          </p>
        </section>

        {/* Menu / services */}
        {services.length > 0 && (
          <section className="mx-auto max-w-xl px-8 pb-14">
            <h2 className="mb-6 text-center font-serif text-2xl italic text-[color:var(--brand)]">
              What we serve
            </h2>
            <ul className="space-y-3">
              {services.map((service, i) => (
                <li
                  key={i}
                  className="flex items-center justify-between border-b border-dashed border-[#D9CFC0] pb-3 text-sm"
                >
                  <span>{service}</span>
                </li>
              ))}
            </ul>
          </section>
        )}

        {/* Gallery */}
        {images.gallery.length > 0 && (
          <section className="px-8 pb-14">
            <div className="mx-auto grid max-w-3xl grid-cols-3 gap-2">
              {images.gallery.slice(0, 6).map((url, i) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  key={i}
                  src={url}
                  alt={`Gallery ${i + 1}`}
                  className="aspect-square w-full rounded-lg object-cover"
                />
              ))}
            </div>
          </section>
        )}

        {/* Footer / contact strip */}
        <footer
          className="px-8 py-10 text-center text-white"
          style={{ backgroundColor: "var(--brand)" }}
        >
          <div className="mx-auto flex max-w-xl flex-col items-center gap-3 text-sm">
            {address && (
              <span className="flex items-center gap-2">
                <MapPin className="h-4 w-4" /> {address}
              </span>
            )}
            {openingHours && (
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4" /> {openingHours}
              </span>
            )}
            <div className="mt-2 flex items-center gap-5">
              {phone && (
                <span className="flex items-center gap-2">
                  <Phone className="h-4 w-4" /> {phone}
                </span>
              )}
              {whatsapp && (
                <span className="flex items-center gap-2">
                  <MessageCircle className="h-4 w-4" /> {whatsapp}
                </span>
              )}
            </div>
          </div>
        </footer>
      </div>
    </BrandColorScope>
  );
}
