import { MapPin, Phone, Clock, MessageCircle, Scissors } from "lucide-react";
import type { WebsiteData } from "@/lib/website-data";
import { ImagePlaceholder } from "@/components/templates/shared/image-placeholder";
import { BrandColorScope } from "@/components/templates/shared/brand-color-scope";

export function BarberTemplate({ data }: { data: WebsiteData }) {
  const { businessName, description, phone, whatsapp, address, openingHours, services, images } =
    data;

  return (
    <BrandColorScope color={data.brandColor}>
      <div className="bg-[#111111] text-white">
        {/* Hero */}
        <section className="relative flex h-[440px] flex-col items-center justify-center overflow-hidden px-8 text-center">
          {images.hero ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={images.hero}
              alt={businessName || "Barber shop hero"}
              className="absolute inset-0 h-full w-full object-cover opacity-40"
            />
          ) : (
            <div className="absolute inset-0 bg-[#1A1A1A]" />
          )}
          <div className="relative z-10">
            {images.logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={images.logo}
                alt="Logo"
                className="mx-auto mb-5 h-16 w-16 rounded-full border-2 object-cover"
                style={{ borderColor: "var(--brand)" }}
              />
            ) : (
              <Scissors
                className="mx-auto mb-5 h-8 w-8"
                style={{ color: "var(--brand)" }}
                strokeWidth={1.5}
              />
            )}
            <h1 className="text-5xl font-black uppercase tracking-tight md:text-6xl">
              {businessName || "Your Barber Shop"}
            </h1>
            <p className="mx-auto mt-4 max-w-md text-sm text-white/60">
              {description || "Sharp cuts. No wait, no compromise."}
            </p>
          </div>
        </section>

        {/* Services / price list */}
        {services.length > 0 && (
          <section className="border-t border-white/10 px-8 py-14">
            <h2 className="mb-8 text-center text-xs font-bold uppercase tracking-[0.2em] text-white/50">
              Services
            </h2>
            <div className="mx-auto grid max-w-2xl gap-3 sm:grid-cols-2">
              {services.map((service, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.03] px-5 py-4"
                >
                  <span className="text-sm font-medium">{service}</span>
                  <span
                    className="h-1.5 w-1.5 rounded-full"
                    style={{ backgroundColor: "var(--brand)" }}
                  />
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Gallery */}
        {images.gallery.length > 0 && (
          <section className="border-t border-white/10 px-8 py-14">
            <div className="mx-auto grid max-w-3xl grid-cols-3 gap-2">
              {images.gallery.slice(0, 6).map((url, i) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  key={i}
                  src={url}
                  alt={`Gallery ${i + 1}`}
                  className="aspect-square w-full object-cover grayscale transition-all hover:grayscale-0"
                />
              ))}
            </div>
          </section>
        )}

        {/* Footer / contact */}
        <footer className="border-t border-white/10 px-8 py-10 text-center">
          <div className="mx-auto flex max-w-xl flex-col items-center gap-3 text-sm text-white/70">
            {address && (
              <span className="flex items-center gap-2">
                <MapPin className="h-4 w-4" style={{ color: "var(--brand)" }} /> {address}
              </span>
            )}
            {openingHours && (
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4" style={{ color: "var(--brand)" }} /> {openingHours}
              </span>
            )}
            <div className="mt-2 flex items-center gap-5">
              {phone && (
                <span className="flex items-center gap-2">
                  <Phone className="h-4 w-4" style={{ color: "var(--brand)" }} /> {phone}
                </span>
              )}
              {whatsapp && (
                <span className="flex items-center gap-2">
                  <MessageCircle className="h-4 w-4" style={{ color: "var(--brand)" }} /> {whatsapp}
                </span>
              )}
            </div>
          </div>
        </footer>
      </div>
    </BrandColorScope>
  );
}
