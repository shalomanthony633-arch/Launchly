import { MapPin, Phone, Clock, MessageCircle, Sparkles } from "lucide-react";
import type { WebsiteData } from "@/lib/website-data";
import { ImagePlaceholder } from "@/components/templates/shared/image-placeholder";
import { BrandColorScope } from "@/components/templates/shared/brand-color-scope";

export function HotelTemplate({ data }: { data: WebsiteData }) {
  const { businessName, description, phone, whatsapp, address, openingHours, services, images } =
    data;

  return (
    <BrandColorScope color={data.brandColor}>
      <div className="bg-white text-[#1A1A1A]">
        {/* Hero */}
        <section className="relative h-[480px] w-full overflow-hidden">
          {images.hero ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={images.hero}
              alt={businessName || "Hotel hero"}
              className="h-full w-full object-cover"
            />
          ) : (
            <ImagePlaceholder className="h-full w-full" label="Hero image" />
          )}
          <div className="absolute inset-0 bg-black/25" />
          <div className="absolute inset-0 flex flex-col items-center justify-center px-8 text-center text-white">
            {images.logo && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={images.logo}
                alt="Logo"
                className="mb-4 h-14 w-14 rounded-full border border-white/70 bg-white/10 object-cover backdrop-blur"
              />
            )}
            <p
              className="mb-2 text-xs font-medium uppercase tracking-[0.3em]"
              style={{ color: "var(--brand)" }}
            >
              Welcome to
            </p>
            <h1 className="text-4xl font-light tracking-wide md:text-5xl">
              {businessName || "Your Hotel Name"}
            </h1>
          </div>
        </section>

        {/* Description */}
        <section className="mx-auto max-w-2xl px-8 py-14 text-center">
          <p className="text-[15px] leading-relaxed text-[#5A5A5A]">
            {description || "Describe the experience guests can expect during their stay."}
          </p>
        </section>

        {/* Amenities / services grid */}
        {services.length > 0 && (
          <section className="bg-[#FAFAF8] px-8 py-14">
            <h2 className="mb-8 text-center text-xs font-medium uppercase tracking-[0.25em] text-[#8A8A8A]">
              Amenities
            </h2>
            <div className="mx-auto grid max-w-3xl grid-cols-2 gap-6 sm:grid-cols-3">
              {services.map((service, i) => (
                <div key={i} className="flex flex-col items-center gap-2 text-center">
                  <Sparkles
                    className="h-5 w-5"
                    style={{ color: "var(--brand)" }}
                    strokeWidth={1.5}
                  />
                  <span className="text-sm text-[#3A3A3A]">{service}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Gallery */}
        {images.gallery.length > 0 && (
          <section className="px-8 py-14">
            <div className="mx-auto grid max-w-4xl grid-cols-2 gap-3 md:grid-cols-4">
              {images.gallery.slice(0, 8).map((url, i) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  key={i}
                  src={url}
                  alt={`Gallery ${i + 1}`}
                  className="aspect-[4/3] w-full rounded-md object-cover"
                />
              ))}
            </div>
          </section>
        )}

        {/* Footer / contact */}
        <footer className="border-t border-[#EEE9E0] px-8 py-10 text-center">
          <div className="mx-auto flex max-w-xl flex-col items-center gap-3 text-sm text-[#5A5A5A]">
            {address && (
              <span className="flex items-center gap-2">
                <MapPin className="h-4 w-4" style={{ color: "var(--brand)" }} /> {address}
              </span>
            )}
            {openingHours && (
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4" style={{ color: "var(--brand)" }} /> {openingHours}
              </span>
            )}
            <div className="mt-2 flex items-center gap-5">
              {phone && (
                <span className="flex items-center gap-2">
                  <Phone className="h-4 w-4" style={{ color: "var(--brand)" }} /> {phone}
                </span>
              )}
              {whatsapp && (
                <span className="flex items-center gap-2">
                  <MessageCircle className="h-4 w-4" style={{ color: "var(--brand)" }} /> {whatsapp}
                </span>
              )}
            </div>
          </div>
        </footer>
      </div>
    </BrandColorScope>
  );
}
