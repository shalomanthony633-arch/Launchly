import type { ReactNode } from "react";

export function BrandColorScope({
  color,
  children,
}: {
  color: string;
  children: ReactNode;
}) {
  return (
    <div style={{ "--brand": color } as React.CSSProperties} className="w-full">
      {children}
    </div>
  );
}
