import { ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function ImagePlaceholder({
  className,
  label = "Image",
}: {
  className?: string;
  label?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-2 bg-slate-100 text-slate-400",
        className
      )}
    >
      <ImageIcon className="h-6 w-6" strokeWidth={1.5} />
      <span className="text-xs">{label}</span>
    </div>
  );
}
