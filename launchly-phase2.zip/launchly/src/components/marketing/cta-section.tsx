import Link from "next/link";
import { Button } from "@/components/ui/button";

export function CtaSection() {
  return (
    <section className="border-t border-border">
      <div className="mx-auto max-w-6xl px-6 py-20 text-center">
        <h2 className="text-3xl font-semibold tracking-tight text-ink-950">
          Your business deserves a website today, not next month.
        </h2>
        <div className="mt-7">
          <Link href="/signup">
            <Button size="lg">Start building for free</Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
