const steps = [
  {
    step: "01",
    title: "Choose a template",
    description: "Pick the layout built for your kind of business.",
  },
  {
    step: "02",
    title: "Add your details",
    description: "Business name, hours, services, and photos — that's it.",
  },
  {
    step: "03",
    title: "Publish",
    description: "Your site goes live at your own Launchly address.",
  },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="mx-auto max-w-6xl px-6 py-20">
      <div className="mx-auto max-w-xl text-center">
        <h2 className="text-3xl font-semibold tracking-tight text-ink-950">
          Three steps. No code.
        </h2>
      </div>

      <ol className="mt-12 grid gap-8 md:grid-cols-3">
        {steps.map((item) => (
          <li key={item.step} className="relative pl-0">
            <span className="text-sm font-semibold text-primary-600">
              {item.step}
            </span>
            <h3 className="mt-2 text-base font-semibold text-ink-950">
              {item.title}
            </h3>
            <p className="mt-1.5 text-sm text-slate-500">
              {item.description}
            </p>
          </li>
        ))}
      </ol>
    </section>
  );
}
