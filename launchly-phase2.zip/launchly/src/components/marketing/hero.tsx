import Link from "next/link";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section className="hero-glow relative overflow-hidden">
      <div className="mx-auto max-w-6xl px-6 pb-20 pt-20 text-center md:pb-28 md:pt-28">
        <div className="mx-auto mb-6 inline-flex animate-fade-in items-center gap-2 rounded-full border border-border bg-white px-3 py-1 text-xs font-medium text-slate-500 shadow-sm">
          <span className="h-1.5 w-1.5 rounded-full bg-success-500" />
          Now live for restaurants, barber shops & hotels
        </div>

        <h1 className="mx-auto max-w-3xl animate-fade-up text-4xl font-semibold tracking-tight text-ink-950 [animation-delay:60ms] [opacity:0] md:text-6xl md:leading-[1.1]">
          A website for your business, live in minutes.
        </h1>

        <p className="mx-auto mt-5 max-w-xl animate-fade-up text-lg text-slate-500 [animation-delay:140ms] [opacity:0]">
          Pick a template, add your details, publish. No code, no
          designer, no waiting around for a developer to reply.
        </p>

        <div className="mt-8 flex animate-fade-up flex-col items-center justify-center gap-3 [animation-delay:220ms] [opacity:0] sm:flex-row">
          <Link href="/signup">
            <Button size="lg" className="group">
              Start building for free
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </Button>
          </Link>
          <a href="#templates">
            <Button variant="secondary" size="lg">
              Browse templates
            </Button>
          </a>
        </div>

        <ul className="mt-8 flex animate-fade-up flex-col items-center justify-center gap-x-6 gap-y-2 text-sm text-slate-500 [animation-delay:300ms] [opacity:0] sm:flex-row">
          <li className="flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4 text-success-600" />
            No credit card required
          </li>
          <li className="flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4 text-success-600" />
            Live in under 10 minutes
          </li>
          <li className="flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4 text-success-600" />
            Edit anytime
          </li>
        </ul>
      </div>
    </section>
  );
}
