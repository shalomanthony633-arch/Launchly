import { UtensilsCrossed, Scissors, BedDouble } from "lucide-react";

const templates = [
  {
    name: "Restaurant",
    description: "Menu, hours, gallery, and reservations in one page.",
    icon: UtensilsCrossed,
    accent: "bg-primary-50 text-primary-600",
  },
  {
    name: "Barber Shop",
    description: "Services, pricing, and booking for walk-ins and regulars.",
    icon: Scissors,
    accent: "bg-success-50 text-success-600",
  },
  {
    name: "Hotel",
    description: "Rooms, amenities, and a gallery guests can browse.",
    icon: BedDouble,
    accent: "bg-primary-50 text-primary-600",
  },
];

export function TemplatesSection() {
  return (
    <section id="templates" className="border-t border-border bg-slate-50/60">
      <div className="mx-auto max-w-6xl px-6 py-20">
        <div className="mx-auto max-w-xl text-center">
          <h2 className="text-3xl font-semibold tracking-tight text-ink-950">
            Built for how your business actually works
          </h2>
          <p className="mt-3 text-slate-500">
            Each template is tuned for its industry, not a generic
            one-size-fits-all page.
          </p>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {templates.map((template) => (
            <div
              key={template.name}
              className="group rounded-2xl border border-border bg-white p-6 shadow-card transition-shadow hover:shadow-card-hover"
            >
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-xl ${template.accent}`}
              >
                <template.icon className="h-5 w-5" strokeWidth={2} />
              </div>
              <h3 className="mt-4 text-base font-semibold text-ink-950">
                {template.name}
              </h3>
              <p className="mt-1.5 text-sm text-slate-500">
                {template.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
