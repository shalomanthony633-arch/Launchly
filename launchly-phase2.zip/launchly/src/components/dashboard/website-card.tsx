"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { MoreVertical, Pencil, Copy, Trash2, Globe } from "lucide-react";
import { TEMPLATE_LABELS, type TemplateId } from "@/lib/website-data";
import { cn } from "@/lib/utils";

export interface WebsiteCardData {
  id: string;
  businessName: string;
  templateId: TemplateId;
  status: "DRAFT" | "PUBLISHED";
  createdAt: string;
  updatedAt: string;
  heroUrl: string | null;
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function WebsiteCard({ website }: { website: WebsiteCardData }) {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isDuplicating, setIsDuplicating] = useState(false);

  async function handleDelete() {
    const confirmed = window.confirm(
      `Delete "${website.businessName}"? This can't be undone.`
    );
    if (!confirmed) return;

    setIsDeleting(true);
    try {
      const res = await fetch(`/api/websites/${website.id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error();
      router.refresh();
    } catch {
      window.alert("Couldn't delete this website. Try again.");
      setIsDeleting(false);
    }
  }

  async function handleDuplicate() {
    setIsDuplicating(true);
    try {
      const res = await fetch(`/api/websites/${website.id}/duplicate`, {
        method: "POST",
      });
      if (!res.ok) throw new Error();
      router.refresh();
    } catch {
      window.alert("Couldn't duplicate this website. Try again.");
    } finally {
      setIsDuplicating(false);
      setMenuOpen(false);
    }
  }

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border bg-white shadow-card transition-shadow hover:shadow-card-hover">
      <Link href={`/dashboard/websites/${website.id}/edit`}>
        <div className="aspect-video w-full bg-slate-100">
          {website.heroUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={website.heroUrl}
              alt={website.businessName}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-slate-300">
              <Globe className="h-8 w-8" strokeWidth={1.5} />
            </div>
          )}
        </div>
      </Link>

      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <Link href={`/dashboard/websites/${website.id}/edit`}>
              <h3 className="truncate text-sm font-semibold text-ink-950 hover:text-primary-600">
                {website.businessName}
              </h3>
            </Link>
            <p className="mt-0.5 text-xs text-slate-500">
              {TEMPLATE_LABELS[website.templateId]}
            </p>
          </div>

          <div className="relative shrink-0">
            <button
              onClick={() => setMenuOpen((v) => !v)}
              className="flex h-7 w-7 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-900"
              aria-label="Website actions"
              aria-haspopup="menu"
            >
              <MoreVertical className="h-4 w-4" />
            </button>

            {menuOpen && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setMenuOpen(false)}
                />
                <div
                  role="menu"
                  className="absolute right-0 z-20 mt-1 w-40 rounded-xl border border-border bg-white p-1.5 shadow-card-hover"
                >
                  <Link
                    href={`/dashboard/websites/${website.id}/edit`}
                    className="flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm text-ink-700 hover:bg-slate-50"
                    role="menuitem"
                  >
                    <Pencil className="h-3.5 w-3.5 text-slate-400" />
                    Edit
                  </Link>
                  <button
                    onClick={handleDuplicate}
                    disabled={isDuplicating}
                    className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm text-ink-700 hover:bg-slate-50 disabled:opacity-50"
                    role="menuitem"
                  >
                    <Copy className="h-3.5 w-3.5 text-slate-400" />
                    {isDuplicating ? "Duplicating…" : "Duplicate"}
                  </button>
                  <button
                    onClick={handleDelete}
                    disabled={isDeleting}
                    className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm text-red-600 hover:bg-red-50 disabled:opacity-50"
                    role="menuitem"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    {isDeleting ? "Deleting…" : "Delete"}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
          <span
            className={cn(
              "rounded-full px-2 py-0.5 font-medium",
              website.status === "DRAFT"
                ? "bg-slate-100 text-slate-500"
                : "bg-success-50 text-success-700"
            )}
          >
            {website.status === "DRAFT" ? "Draft" : "Published"}
          </span>
          <span>Updated {formatDate(website.updatedAt)}</span>
        </div>
      </div>
    </div>
  );
}
