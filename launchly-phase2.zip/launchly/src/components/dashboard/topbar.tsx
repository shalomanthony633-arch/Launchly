"use client";

import { useState, useRef, useEffect } from "react";
import { signOut } from "next-auth/react";
import { ChevronDown, LogOut, Settings, User } from "lucide-react";
import Link from "next/link";

export function Topbar({
  userName,
  userEmail,
}: {
  userName: string;
  userEmail: string;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const initials = userName
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-white px-6">
      <div className="md:hidden">
        <span className="text-sm font-semibold text-ink-950">Launchly</span>
      </div>
      <div className="hidden md:block" />

      <div className="relative" ref={menuRef}>
        <button
          onClick={() => setIsOpen((v) => !v)}
          className="flex items-center gap-2.5 rounded-lg border border-border px-2.5 py-1.5 transition-colors hover:bg-slate-50"
          aria-haspopup="menu"
          aria-expanded={isOpen}
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary-100 text-xs font-semibold text-primary-700">
            {initials || <User className="h-3.5 w-3.5" />}
          </span>
          <span className="hidden text-sm font-medium text-ink-900 sm:inline">
            {userName}
          </span>
          <ChevronDown className="h-4 w-4 text-slate-400" />
        </button>

        {isOpen && (
          <div
            role="menu"
            className="absolute right-0 mt-2 w-56 rounded-xl border border-border bg-white p-1.5 shadow-card-hover animate-fade-in"
          >
            <div className="px-2.5 py-2">
              <p className="truncate text-sm font-medium text-ink-900">
                {userName}
              </p>
              <p className="truncate text-xs text-slate-500">{userEmail}</p>
            </div>
            <div className="my-1 h-px bg-border" />
            <Link
              href="/dashboard/settings"
              className="flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm text-ink-700 hover:bg-slate-50"
              role="menuitem"
            >
              <Settings className="h-4 w-4 text-slate-400" />
              Settings
            </Link>
            <button
              onClick={() => signOut({ callbackUrl: "/" })}
              className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm text-red-600 hover:bg-red-50"
              role="menuitem"
            >
              <LogOut className="h-4 w-4" />
              Log out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
