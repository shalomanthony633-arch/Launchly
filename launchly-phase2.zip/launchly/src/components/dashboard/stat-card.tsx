import type { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  accent?: "primary" | "success" | "neutral";
}

const accentStyles = {
  primary: "bg-primary-50 text-primary-600",
  success: "bg-success-50 text-success-600",
  neutral: "bg-slate-100 text-slate-500",
};

export function StatCard({
  label,
  value,
  icon: Icon,
  accent = "neutral",
}: StatCardProps) {
  return (
    <Card>
      <CardContent className="flex items-start justify-between p-5">
        <div>
          <p className="text-sm text-slate-500">{label}</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-ink-950">
            {value}
          </p>
        </div>
        <div
          className={cn(
            "flex h-9 w-9 items-center justify-center rounded-lg",
            accentStyles[accent]
          )}
        >
          <Icon className="h-[18px] w-[18px]" strokeWidth={2} />
        </div>
      </CardContent>
    </Card>
  );
}
