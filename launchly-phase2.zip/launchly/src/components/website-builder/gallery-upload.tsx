"use client";

import { useRef } from "react";
import { Upload, X } from "lucide-react";

interface GalleryImage {
  id: string;
  url: string;
  isUploading?: boolean;
}

export function GalleryUpload({
  images,
  onSelect,
  onRemove,
  maxImages = 10,
}: {
  images: GalleryImage[];
  onSelect: (files: FileList) => void;
  onRemove: (id: string) => void;
  maxImages?: number;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div>
      <p className="mb-1.5 text-sm font-medium text-ink-900">Gallery images</p>
      <p className="mb-2 text-xs text-slate-500">
        Up to {maxImages} photos. JPG, PNG, WEBP, or GIF, 5MB each.
      </p>

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onSelect(e.target.files);
          }
          e.target.value = "";
        }}
      />

      <div className="grid grid-cols-4 gap-2">
        {images.map((img) => (
          <div
            key={img.id}
            className="group relative aspect-square overflow-hidden rounded-lg border border-border"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img.url} alt="Gallery" className="h-full w-full object-cover" />
            <button
              type="button"
              onClick={() => onRemove(img.id)}
              className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition-opacity group-hover:opacity-100"
              aria-label="Remove image"
            >
              <X className="h-3 w-3" />
            </button>
            {img.isUploading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
              </div>
            )}
          </div>
        ))}

        {images.length < maxImages && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="flex aspect-square flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-border-strong bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100"
          >
            <Upload className="h-4 w-4" strokeWidth={1.5} />
            <span className="text-[10px]">Add</span>
          </button>
        )}
      </div>
    </div>
  );
}
