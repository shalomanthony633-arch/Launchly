"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FormError } from "@/components/ui/form-error";
import { FormSection } from "@/components/website-builder/form-section";
import { TemplatePicker } from "@/components/website-builder/template-picker";
import { ServicesEditor } from "@/components/website-builder/services-editor";
import { ImageUploadSlot } from "@/components/website-builder/image-upload-slot";
import { GalleryUpload } from "@/components/website-builder/gallery-upload";
import { ColorPicker } from "@/components/website-builder/color-picker";
import { PreviewFrame } from "@/components/website-builder/preview-frame";
import { renderTemplate } from "@/components/templates/template-registry";
import { websiteFormSchema } from "@/lib/validation";
import type {
  WebsiteFormData,
  WebsiteImages,
  TemplateId,
} from "@/lib/website-data";

interface GalleryItem {
  id: string;
  url: string;
  isUploading?: boolean;
}

interface WebsiteBuilderProps {
  mode: "create" | "edit";
  websiteId?: string;
  initialForm: WebsiteFormData;
  initialImages: WebsiteImages;
  initialGalleryIds?: string[]; // real WebsiteImage ids for gallery, edit mode only
}

export function WebsiteBuilder({
  mode,
  websiteId,
  initialForm,
  initialImages,
  initialGalleryIds,
}: WebsiteBuilderProps) {
  const router = useRouter();
  const [form, setForm] = useState<WebsiteFormData>(initialForm);
  const [logoUrl, setLogoUrl] = useState<string | null>(initialImages.logo);
  const [heroUrl, setHeroUrl] = useState<string | null>(initialImages.hero);
  const [gallery, setGallery] = useState<GalleryItem[]>(
    initialImages.gallery.map((url, i) => ({
      id: initialGalleryIds?.[i] ?? `existing-${i}`,
      url,
    }))
  );
  const [logoUploading, setLogoUploading] = useState(false);
  const [heroUploading, setHeroUploading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [isSaving, setIsSaving] = useState(false);

  // For create mode, images can't upload until a website row exists (uploads
  // are scoped to a websiteId). We lazily create a draft row on first upload.
  const [draftWebsiteId, setDraftWebsiteId] = useState<string | undefined>(
    websiteId
  );

  function updateField<K extends keyof WebsiteFormData>(
    key: K,
    value: WebsiteFormData[K]
  ) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function ensureWebsiteId(): Promise<string> {
    if (draftWebsiteId) return draftWebsiteId;

    const res = await fetch("/api/websites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error ?? "Couldn't start your website");
    setDraftWebsiteId(data.website.id);
    return data.website.id as string;
  }

  async function uploadImage(file: File, kind: "LOGO" | "HERO" | "GALLERY") {
    const id = await ensureWebsiteId();
    const body = new FormData();
    body.append("file", file);
    body.append("kind", kind);

    const res = await fetch(`/api/websites/${id}/images`, {
      method: "POST",
      body,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error ?? "Upload failed");
    return data.image as { id: string; url: string };
  }

  async function handleLogoSelect(file: File) {
    // Instant local preview before the network call resolves.
    const localPreview = URL.createObjectURL(file);
    setLogoUrl(localPreview);
    setLogoUploading(true);
    try {
      const image = await uploadImage(file, "LOGO");
      setLogoUrl(image.url);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Logo upload failed");
      setLogoUrl(initialImages.logo);
    } finally {
      setLogoUploading(false);
    }
  }

  async function handleHeroSelect(file: File) {
    const localPreview = URL.createObjectURL(file);
    setHeroUrl(localPreview);
    setHeroUploading(true);
    try {
      const image = await uploadImage(file, "HERO");
      setHeroUrl(image.url);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Hero image upload failed");
      setHeroUrl(initialImages.hero);
    } finally {
      setHeroUploading(false);
    }
  }

  async function handleGallerySelect(files: FileList) {
    const remaining = 10 - gallery.length;
    const toUpload = Array.from(files).slice(0, remaining);

    for (const file of toUpload) {
      const tempId = `pending-${Date.now()}-${Math.random()}`;
      const localPreview = URL.createObjectURL(file);
      setGallery((g) => [...g, { id: tempId, url: localPreview, isUploading: true }]);

      try {
        const image = await uploadImage(file, "GALLERY");
        setGallery((g) =>
          g.map((item) =>
            item.id === tempId ? { id: image.id, url: image.url } : item
          )
        );
      } catch (err) {
        setFormError(err instanceof Error ? err.message : "Gallery upload failed");
        setGallery((g) => g.filter((item) => item.id !== tempId));
      }
    }
  }

  async function handleRemoveLogo() {
    if (draftWebsiteId && logoUrl && !logoUrl.startsWith("blob:")) {
      // We don't track the logo's image id client-side by design (it's a
      // single slot) — the API resolves it server-side isn't available for
      // DELETE by kind, so we just clear it locally; next upload replaces
      // it server-side automatically. Full removal without replacement is
      // a rare edge case, acceptable to leave for a future refinement.
    }
    setLogoUrl(null);
  }

  async function handleRemoveHero() {
    setHeroUrl(null);
  }

  async function handleRemoveGalleryImage(id: string) {
    setGallery((g) => g.filter((item) => item.id !== id));
    if (draftWebsiteId && !id.startsWith("pending-") && !id.startsWith("existing-")) {
      try {
        await fetch(`/api/websites/${draftWebsiteId}/images?imageId=${id}`, {
          method: "DELETE",
        });
      } catch {
        // Non-fatal — image stays removed from the UI regardless.
      }
    }
  }

  async function handleSave() {
    setFormError(null);
    setFieldErrors({});

    const parsed = websiteFormSchema.safeParse(form);
    if (!parsed.success) {
      const errors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as string;
        if (!errors[key]) errors[key] = issue.message;
      }
      setFieldErrors(errors);
      setFormError("Fix the highlighted fields before saving.");
      return;
    }

    setIsSaving(true);
    try {
      const id = await ensureWebsiteId();
      const res = await fetch(`/api/websites/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Couldn't save your website");

      router.push("/dashboard/websites");
      router.refresh();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Something went wrong");
      setIsSaving(false);
    }
  }

  const previewData = {
    ...form,
    images: {
      logo: logoUrl,
      hero: heroUrl,
      gallery: gallery.map((g) => g.url),
    },
  };

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
      {/* Left: form */}
      <div>
        <FormSection
          title="Template"
          description="Pick the layout built for your kind of business."
        >
          <TemplatePicker
            value={form.templateId}
            onChange={(id: TemplateId) => updateField("templateId", id)}
          />
        </FormSection>

        <FormSection title="Business details">
          <div>
            <Label htmlFor="businessName">Business name</Label>
            <Input
              id="businessName"
              value={form.businessName}
              hasError={!!fieldErrors.businessName}
              onChange={(e) => updateField("businessName", e.target.value)}
              placeholder="e.g. The Grove Kitchen"
            />
            <FormError message={fieldErrors.businessName} />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              rows={3}
              value={form.description}
              hasError={!!fieldErrors.description}
              onChange={(e) => updateField("description", e.target.value)}
              placeholder="What makes your business worth visiting?"
            />
            <FormError message={fieldErrors.description} />
          </div>
        </FormSection>

        <FormSection title="Contact information">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="phone">Phone number</Label>
              <Input
                id="phone"
                value={form.phone}
                hasError={!!fieldErrors.phone}
                onChange={(e) => updateField("phone", e.target.value)}
                placeholder="+234 801 234 5678"
              />
              <FormError message={fieldErrors.phone} />
            </div>
            <div>
              <Label htmlFor="whatsapp">WhatsApp number</Label>
              <Input
                id="whatsapp"
                value={form.whatsapp}
                hasError={!!fieldErrors.whatsapp}
                onChange={(e) => updateField("whatsapp", e.target.value)}
                placeholder="+234 801 234 5678"
              />
              <FormError message={fieldErrors.whatsapp} />
            </div>
          </div>

          <div>
            <Label htmlFor="email">Email address</Label>
            <Input
              id="email"
              type="email"
              value={form.email}
              hasError={!!fieldErrors.email}
              onChange={(e) => updateField("email", e.target.value)}
              placeholder="hello@yourbusiness.com"
            />
            <FormError message={fieldErrors.email} />
          </div>

          <div>
            <Label htmlFor="address">Physical address</Label>
            <Input
              id="address"
              value={form.address}
              hasError={!!fieldErrors.address}
              onChange={(e) => updateField("address", e.target.value)}
              placeholder="12 Admiralty Way, Lekki, Lagos"
            />
            <FormError message={fieldErrors.address} />
          </div>

          <div>
            <Label htmlFor="openingHours">Opening hours</Label>
            <Input
              id="openingHours"
              value={form.openingHours}
              hasError={!!fieldErrors.openingHours}
              onChange={(e) => updateField("openingHours", e.target.value)}
              placeholder="Mon–Sat, 9am–9pm"
            />
            <FormError message={fieldErrors.openingHours} />
          </div>
        </FormSection>

        <FormSection
          title="Services"
          description="Menu items, haircut types, room categories — whatever your business offers."
        >
          <ServicesEditor
            services={form.services}
            onChange={(services) => updateField("services", services)}
          />
        </FormSection>

        <FormSection title="Brand color">
          <ColorPicker
            value={form.brandColor}
            onChange={(color) => updateField("brandColor", color)}
          />
        </FormSection>

        <FormSection title="Images">
          <div className="flex flex-wrap gap-5">
            <ImageUploadSlot
              label="Logo"
              previewUrl={logoUrl}
              onSelect={handleLogoSelect}
              onRemove={handleRemoveLogo}
              isUploading={logoUploading}
            />
          </div>

          <ImageUploadSlot
            label="Hero image"
            helpText="The large banner image at the top of your site."
            previewUrl={heroUrl}
            onSelect={handleHeroSelect}
            onRemove={handleRemoveHero}
            aspect="wide"
            isUploading={heroUploading}
          />

          <GalleryUpload
            images={gallery}
            onSelect={handleGallerySelect}
            onRemove={handleRemoveGalleryImage}
          />
        </FormSection>

        <FormError message={formError} />

        <div className="pt-6">
          <Button size="lg" onClick={handleSave} isLoading={isSaving}>
            <Save className="h-4 w-4" />
            {mode === "create" ? "Save website" : "Save changes"}
          </Button>
        </div>
      </div>

      {/* Right: live preview */}
      <div>
        <PreviewFrame>{renderTemplate(previewData)}</PreviewFrame>
      </div>
    </div>
  );
}
