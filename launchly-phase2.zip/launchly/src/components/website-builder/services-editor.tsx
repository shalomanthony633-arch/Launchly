"use client";

import { useState } from "react";
import { X, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function ServicesEditor({
  services,
  onChange,
}: {
  services: string[];
  onChange: (services: string[]) => void;
}) {
  const [draft, setDraft] = useState("");

  function addService() {
    const trimmed = draft.trim();
    if (!trimmed || services.length >= 20) return;
    onChange([...services, trimmed]);
    setDraft("");
  }

  function removeService(index: number) {
    onChange(services.filter((_, i) => i !== index));
  }

  return (
    <div>
      <div className="flex gap-2">
        <Input
          value={draft}
          placeholder="e.g. Haircut & Fade — ₦3,500"
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              addService();
            }
          }}
        />
        <Button type="button" variant="secondary" onClick={addService}>
          <Plus className="h-4 w-4" />
          Add
        </Button>
      </div>

      {services.length > 0 && (
        <ul className="mt-3 space-y-1.5">
          {services.map((service, i) => (
            <li
              key={i}
              className="flex items-center justify-between rounded-lg border border-border bg-slate-50 px-3 py-2 text-sm"
            >
              <span className="text-ink-900">{service}</span>
              <button
                type="button"
                onClick={() => removeService(i)}
                className="text-slate-400 transition-colors hover:text-red-600"
                aria-label={`Remove ${service}`}
              >
                <X className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-1.5 text-xs text-slate-400">
        {services.length}/20 services added
      </p>
    </div>
  );
}
