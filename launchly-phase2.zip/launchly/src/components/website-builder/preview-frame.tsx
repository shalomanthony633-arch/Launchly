import type { ReactNode } from "react";

export function PreviewFrame({ children }: { children: ReactNode }) {
  return (
    <div className="sticky top-6 overflow-hidden rounded-2xl border border-border bg-white shadow-card">
      <div className="flex items-center gap-1.5 border-b border-border bg-slate-50 px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-red-300" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber-300" />
        <span className="h-2.5 w-2.5 rounded-full bg-green-300" />
        <span className="ml-3 truncate text-xs text-slate-400">Live preview</span>
      </div>
      <div className="max-h-[calc(100vh-160px)] overflow-y-auto">{children}</div>
    </div>
  );
}
