"use client";

import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const PRESET_COLORS = [
  "#2563EB", // blue
  "#16A34A", // green
  "#DC2626", // red
  "#D97706", // amber
  "#7C3AED", // violet
  "#0891B2", // cyan
  "#DB2777", // pink
  "#171717", // near-black
];

export function ColorPicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (color: string) => void;
}) {
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        {PRESET_COLORS.map((color) => (
          <button
            key={color}
            type="button"
            onClick={() => onChange(color)}
            aria-label={`Select color ${color}`}
            className={cn(
              "h-8 w-8 rounded-full border-2 transition-transform hover:scale-110",
              value.toLowerCase() === color.toLowerCase()
                ? "border-ink-900"
                : "border-transparent"
            )}
            style={{ backgroundColor: color }}
          />
        ))}
      </div>

      <div className="mt-3 flex items-center gap-2">
        <input
          type="color"
          value={/^#[0-9A-Fa-f]{6}$/.test(value) ? value : "#2563EB"}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 w-9 cursor-pointer rounded-lg border border-border p-0.5"
          aria-label="Custom color picker"
        />
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="#2563EB"
          className="w-32 font-mono text-xs"
        />
      </div>
    </div>
  );
}
