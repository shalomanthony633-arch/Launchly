"use client";

import { useRef } from "react";
import { Upload, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface ImageUploadSlotProps {
  label: string;
  helpText?: string;
  previewUrl: string | null;
  onSelect: (file: File) => void;
  onRemove: () => void;
  aspect?: "square" | "wide";
  isUploading?: boolean;
}

export function ImageUploadSlot({
  label,
  helpText,
  previewUrl,
  onSelect,
  onRemove,
  aspect = "square",
  isUploading = false,
}: ImageUploadSlotProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div>
      <p className="mb-1.5 text-sm font-medium text-ink-900">{label}</p>
      {helpText && <p className="mb-2 text-xs text-slate-500">{helpText}</p>}

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onSelect(file);
          e.target.value = "";
        }}
      />

      {previewUrl ? (
        <div
          className={cn(
            "group relative overflow-hidden rounded-xl border border-border",
            aspect === "square" ? "aspect-square w-32" : "aspect-video w-full"
          )}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={previewUrl} alt={label} className="h-full w-full object-cover" />
          <button
            type="button"
            onClick={onRemove}
            className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition-opacity group-hover:opacity-100"
            aria-label={`Remove ${label}`}
          >
            <X className="h-3.5 w-3.5" />
          </button>
          {isUploading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/40">
              <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent" />
            </div>
          )}
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={isUploading}
          className={cn(
            "flex flex-col items-center justify-center gap-1.5 rounded-xl border border-dashed border-border-strong bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100",
            aspect === "square" ? "aspect-square w-32" : "aspect-video w-full"
          )}
        >
          {isUploading ? (
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-slate-300 border-t-slate-500" />
          ) : (
            <>
              <Upload className="h-5 w-5" strokeWidth={1.5} />
              <span className="text-xs">Upload</span>
            </>
          )}
        </button>
      )}
    </div>
  );
}
