import { UtensilsCrossed, Scissors, BedDouble, Check } from "lucide-react";
import { TEMPLATE_IDS, TEMPLATE_LABELS, type TemplateId } from "@/lib/website-data";
import { cn } from "@/lib/utils";

const TEMPLATE_ICONS: Record<TemplateId, typeof UtensilsCrossed> = {
  RESTAURANT: UtensilsCrossed,
  BARBER: Scissors,
  HOTEL: BedDouble,
};

const TEMPLATE_DESCRIPTIONS: Record<TemplateId, string> = {
  RESTAURANT: "Warm, editorial layout with a menu-style service list.",
  BARBER: "Bold, high-contrast layout with a price-list grid.",
  HOTEL: "Airy, spacious layout built around a gallery.",
};

export function TemplatePicker({
  value,
  onChange,
}: {
  value: TemplateId;
  onChange: (id: TemplateId) => void;
}) {
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      {TEMPLATE_IDS.map((id) => {
        const Icon = TEMPLATE_ICONS[id];
        const isSelected = value === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange(id)}
            className={cn(
              "relative flex flex-col items-start gap-2 rounded-xl border p-4 text-left transition-colors",
              isSelected
                ? "border-primary-500 bg-primary-50/60 ring-1 ring-primary-500"
                : "border-border hover:bg-slate-50"
            )}
          >
            {isSelected && (
              <span className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-primary-600 text-white">
                <Check className="h-3 w-3" strokeWidth={3} />
              </span>
            )}
            <Icon
              className={cn("h-5 w-5", isSelected ? "text-primary-600" : "text-slate-400")}
              strokeWidth={2}
            />
            <span className="text-sm font-medium text-ink-950">
              {TEMPLATE_LABELS[id]}
            </span>
            <span className="text-xs text-slate-500">
              {TEMPLATE_DESCRIPTIONS[id]}
            </span>
          </button>
        );
      })}
    </div>
  );
}
