import type { ReactNode } from "react";

export function FormSection({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <section className="border-b border-border pb-7 pt-7 first:pt-0">
      <h2 className="text-sm font-semibold text-ink-950">{title}</h2>
      {description && (
        <p className="mt-0.5 text-xs text-slate-500">{description}</p>
      )}
      <div className="mt-4 space-y-4">{children}</div>
    </section>
  );
}
