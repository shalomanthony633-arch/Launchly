import Link from "next/link";
import { getServerSession } from "next-auth";
import { Globe, Activity, CreditCard, Users, Plus } from "lucide-react";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { StatCard } from "@/components/dashboard/stat-card";
import { EmptyState } from "@/components/dashboard/empty-state";
import { Button } from "@/components/ui/button";

export const metadata = {
  title: "Dashboard — Launchly",
};

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const firstName = session?.user?.name?.split(" ")[0] ?? "there";

  const websites = session?.user
    ? await prisma.website.findMany({
        where: { userId: session.user.id },
        orderBy: { updatedAt: "desc" },
        take: 5,
      })
    : [];

  const totalCount = session?.user
    ? await prisma.website.count({ where: { userId: session.user.id } })
    : 0;
  const publishedCount = session?.user
    ? await prisma.website.count({
        where: { userId: session.user.id, status: "PUBLISHED" },
      })
    : 0;

  const statusLabel =
    totalCount === 0
      ? "None yet"
      : publishedCount === 0
        ? "All drafts"
        : `${publishedCount} live`;

  return (
    <div>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink-950">
            Welcome back, {firstName}
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Here&apos;s what&apos;s happening with your websites.
          </p>
        </div>
        <Link href="/dashboard/websites/new">
          <Button size="md">
            <Plus className="h-4 w-4" />
            Create Website
          </Button>
        </Link>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Websites"
          value={String(totalCount)}
          icon={Globe}
          accent="primary"
        />
        <StatCard
          label="Website status"
          value={statusLabel}
          icon={Activity}
          accent="neutral"
        />
        <StatCard
          label="Subscription"
          value="Free plan"
          icon={CreditCard}
          accent="success"
        />
        <StatCard
          label="Visitors (30d)"
          value="0"
          icon={Users}
          accent="neutral"
        />
      </div>

      <div className="mt-8">
        <h2 className="text-sm font-medium text-ink-900">Recent activity</h2>
        <div className="mt-3">
          {websites.length === 0 ? (
            <EmptyState
              icon={Activity}
              title="No activity yet"
              description="Once you create your first website, updates and publishes will show up here."
            />
          ) : (
            <div className="overflow-hidden rounded-2xl border border-border bg-white">
              <ul className="divide-y divide-border">
                {websites.map((site) => (
                  <li key={site.id}>
                    <Link
                      href={`/dashboard/websites/${site.id}/edit`}
                      className="flex items-center justify-between px-5 py-3.5 text-sm hover:bg-slate-50"
                    >
                      <span className="font-medium text-ink-900">
                        {site.businessName}
                      </span>
                      <span className="text-xs text-slate-400">
                        Updated{" "}
                        {new Date(site.updatedAt).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
