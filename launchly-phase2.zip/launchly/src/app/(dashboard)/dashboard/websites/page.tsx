import Link from "next/link";
import { Plus, Globe } from "lucide-react";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { Button } from "@/components/ui/button";
import { WebsiteCard } from "@/components/dashboard/website-card";
import { EmptyState } from "@/components/dashboard/empty-state";

export const metadata = {
  title: "My Websites — Launchly",
};

export default async function WebsitesPage() {
  const session = await getServerSession(authOptions);
  const websites = session?.user
    ? await prisma.website.findMany({
        where: { userId: session.user.id },
        orderBy: { updatedAt: "desc" },
        include: { images: true },
      })
    : [];

  return (
    <div>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink-950">
            My Websites
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Manage the websites you&apos;ve created.
          </p>
        </div>
        <Link href="/dashboard/websites/new">
          <Button size="md">
            <Plus className="h-4 w-4" />
            Create Website
          </Button>
        </Link>
      </div>

      <div className="mt-6">
        {websites.length === 0 ? (
          <EmptyState
            icon={Globe}
            title="No websites yet"
            description="Create your first website — pick a template, add your details, and see it update live as you type."
          />
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {websites.map((website) => (
              <WebsiteCard
                key={website.id}
                website={{
                  id: website.id,
                  businessName: website.businessName,
                  templateId: website.templateId as "RESTAURANT" | "BARBER" | "HOTEL",
                  status: website.status,
                  createdAt: website.createdAt.toISOString(),
                  updatedAt: website.updatedAt.toISOString(),
                  heroUrl: website.images.find((i) => i.kind === "HERO")?.url ?? null,
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
