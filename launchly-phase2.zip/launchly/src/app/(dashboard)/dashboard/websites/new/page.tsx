import { WebsiteBuilder } from "@/components/website-builder/website-builder";
import { EMPTY_WEBSITE_FORM, EMPTY_WEBSITE_IMAGES } from "@/lib/website-data";

export const metadata = {
  title: "Create Website — Launchly",
};

export default function NewWebsitePage() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight text-ink-950">
          Create a website
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Fill in your business details on the left — your site updates live
          on the right as you type.
        </p>
      </div>

      <WebsiteBuilder
        mode="create"
        initialForm={EMPTY_WEBSITE_FORM}
        initialImages={EMPTY_WEBSITE_IMAGES}
      />
    </div>
  );
}
