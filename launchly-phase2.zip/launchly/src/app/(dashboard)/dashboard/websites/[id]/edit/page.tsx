import { notFound } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getOwnedWebsite } from "@/lib/website-ownership";
import { toWebsiteData } from "@/lib/website-data";
import { WebsiteBuilder } from "@/components/website-builder/website-builder";

export const metadata = {
  title: "Edit Website — Launchly",
};

export default async function EditWebsitePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    notFound();
  }

  const website = await getOwnedWebsite(id, session.user.id);
  if (!website) {
    notFound();
  }

  const data = toWebsiteData(website, website.images);
  const galleryIds = website.images
    .filter((img) => img.kind === "GALLERY")
    .map((img) => img.id);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight text-ink-950">
          Edit {website.businessName}
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Changes update the live preview instantly. Click save when you&apos;re
          happy.
        </p>
      </div>

      <WebsiteBuilder
        mode="edit"
        websiteId={website.id}
        initialForm={{
          templateId: data.templateId,
          businessName: data.businessName,
          description: data.description,
          phone: data.phone,
          whatsapp: data.whatsapp,
          email: data.email,
          address: data.address,
          openingHours: data.openingHours,
          services: data.services,
          brandColor: data.brandColor,
        }}
        initialImages={data.images}
        initialGalleryIds={galleryIds}
      />
    </div>
  );
}
