import { NextResponse } from "next/server";
import { readFile, writeFile, mkdir } from "fs/promises";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import { prisma } from "@/lib/prisma";
import { getSessionUserId } from "@/lib/session";
import { getOwnedWebsite } from "@/lib/website-ownership";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function POST(_request: Request, { params }: RouteParams) {
  const userId = await getSessionUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const source = await getOwnedWebsite(id, userId);
  if (!source) {
    return NextResponse.json({ error: "Website not found" }, { status: 404 });
  }

  const newWebsite = await prisma.website.create({
    data: {
      userId,
      templateId: source.templateId,
      status: "DRAFT",
      businessName: `${source.businessName} (Copy)`,
      description: source.description,
      phone: source.phone,
      whatsapp: source.whatsapp,
      email: source.email,
      address: source.address,
      openingHours: source.openingHours,
      services: source.services,
      brandColor: source.brandColor,
    },
  });

  // Copy image files on disk so the duplicate doesn't share files with the
  // original (editing/deleting one shouldn't affect the other).
  const newImages = await Promise.all(
    source.images.map(async (img) => {
      const sourcePath = path.join(process.cwd(), "public", img.url);
      const dir = path.join(process.cwd(), "public", "uploads", userId, newWebsite.id);
      await mkdir(dir, { recursive: true });

      const ext = path.extname(img.url);
      const filename = `${uuidv4()}${ext}`;
      const destPath = path.join(dir, filename);

      try {
        const buffer = await readFile(sourcePath);
        await writeFile(destPath, buffer);
      } catch {
        // Source file missing on disk — skip copying this one image rather
        // than failing the whole duplicate operation.
        return null;
      }

      return {
        websiteId: newWebsite.id,
        kind: img.kind,
        url: `/uploads/${userId}/${newWebsite.id}/${filename}`,
      };
    })
  );

  const validImages = newImages.filter(
    (img): img is NonNullable<typeof img> => img !== null
  );

  if (validImages.length > 0) {
    await prisma.websiteImage.createMany({ data: validImages });
  }

  const websiteWithImages = await prisma.website.findUnique({
    where: { id: newWebsite.id },
    include: { images: true },
  });

  return NextResponse.json({ website: websiteWithImages }, { status: 201 });
}
