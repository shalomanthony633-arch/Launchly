import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionUserId } from "@/lib/session";
import { getOwnedWebsite } from "@/lib/website-ownership";
import { saveUploadedImage, deleteUploadedImage, UploadError } from "@/lib/storage";

interface RouteParams {
  params: Promise<{ id: string }>;
}

const VALID_KINDS = new Set(["LOGO", "HERO", "GALLERY"]);

export async function POST(request: Request, { params }: RouteParams) {
  const userId = await getSessionUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const website = await getOwnedWebsite(id, userId);
  if (!website) {
    return NextResponse.json({ error: "Website not found" }, { status: 404 });
  }

  const formData = await request.formData().catch(() => null);
  const file = formData?.get("file");
  const kind = formData?.get("kind");

  if (!(file instanceof File) || typeof kind !== "string" || !VALID_KINDS.has(kind)) {
    return NextResponse.json({ error: "Missing file or image type" }, { status: 400 });
  }

  try {
    const url = await saveUploadedImage(file, { userId, websiteId: id });

    // Logo and hero are single-image slots — replace any existing one.
    if (kind === "LOGO" || kind === "HERO") {
      const existing = website.images.find((img) => img.kind === kind);
      if (existing) {
        await deleteUploadedImage(existing.url);
        await prisma.websiteImage.delete({ where: { id: existing.id } });
      }
    }

    const image = await prisma.websiteImage.create({
      data: { websiteId: id, kind: kind as "LOGO" | "HERO" | "GALLERY", url },
    });

    return NextResponse.json({ image }, { status: 201 });
  } catch (err) {
    if (err instanceof UploadError) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
    return NextResponse.json({ error: "Upload failed" }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: RouteParams) {
  const userId = await getSessionUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const website = await getOwnedWebsite(id, userId);
  if (!website) {
    return NextResponse.json({ error: "Website not found" }, { status: 404 });
  }

  const { searchParams } = new URL(request.url);
  const imageId = searchParams.get("imageId");
  const image = website.images.find((img) => img.id === imageId);

  if (!image) {
    return NextResponse.json({ error: "Image not found" }, { status: 404 });
  }

  await deleteUploadedImage(image.url);
  await prisma.websiteImage.delete({ where: { id: image.id } });

  return NextResponse.json({ success: true });
}
