import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionUserId } from "@/lib/session";
import { websiteFormSchema } from "@/lib/validation";
import { serializeServices } from "@/lib/website-data";
import { getOwnedWebsite } from "@/lib/website-ownership";
import { deleteUploadedImage } from "@/lib/storage";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function GET(_request: Request, { params }: RouteParams) {
  const userId = await getSessionUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const website = await getOwnedWebsite(id, userId);
  if (!website) {
    return NextResponse.json({ error: "Website not found" }, { status: 404 });
  }

  return NextResponse.json({ website });
}

export async function PATCH(request: Request, { params }: RouteParams) {
  const userId = await getSessionUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const existing = await getOwnedWebsite(id, userId);
  if (!existing) {
    return NextResponse.json({ error: "Website not found" }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  if (!body) {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const parsed = websiteFormSchema.safeParse(body);
  if (!parsed.success) {
    const firstIssue = parsed.error.issues[0];
    return NextResponse.json(
      { error: firstIssue?.message ?? "Invalid input" },
      { status: 400 }
    );
  }

  const data = parsed.data;

  const website = await prisma.website.update({
    where: { id },
    data: {
      templateId: data.templateId,
      businessName: data.businessName,
      description: data.description,
      phone: data.phone,
      whatsapp: data.whatsapp,
      email: data.email,
      address: data.address,
      openingHours: data.openingHours,
      services: serializeServices(data.services),
      brandColor: data.brandColor,
    },
    include: { images: true },
  });

  return NextResponse.json({ website });
}

export async function DELETE(_request: Request, { params }: RouteParams) {
  const userId = await getSessionUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const website = await getOwnedWebsite(id, userId);
  if (!website) {
    return NextResponse.json({ error: "Website not found" }, { status: 404 });
  }

  // Clean up files on disk before removing the DB rows (cascade handles
  // the WebsiteImage rows themselves).
  await Promise.all(website.images.map((img) => deleteUploadedImage(img.url)));
  await prisma.website.delete({ where: { id } });

  return NextResponse.json({ success: true });
}
