import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionUserId } from "@/lib/session";
import { websiteFormSchema } from "@/lib/validation";
import { serializeServices } from "@/lib/website-data";

export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const websites = await prisma.website.findMany({
    where: { userId },
    orderBy: { updatedAt: "desc" },
    include: { images: true },
  });

  return NextResponse.json({ websites });
}

export async function POST(request: Request) {
  const userId = await getSessionUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  if (!body) {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const parsed = websiteFormSchema.safeParse(body);
  if (!parsed.success) {
    const firstIssue = parsed.error.issues[0];
    return NextResponse.json(
      { error: firstIssue?.message ?? "Invalid input" },
      { status: 400 }
    );
  }

  const data = parsed.data;

  const website = await prisma.website.create({
    data: {
      userId,
      templateId: data.templateId,
      businessName: data.businessName,
      description: data.description,
      phone: data.phone,
      whatsapp: data.whatsapp,
      email: data.email,
      address: data.address,
      openingHours: data.openingHours,
      services: serializeServices(data.services),
      brandColor: data.brandColor,
    },
    include: { images: true },
  });

  return NextResponse.json({ website }, { status: 201 });
}
