export interface AppUser {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  createdAt: string;
}

/** Shape safe to expose to the client / session (never includes passwordHash). */
export type PublicUser = Omit<AppUser, "passwordHash">;
